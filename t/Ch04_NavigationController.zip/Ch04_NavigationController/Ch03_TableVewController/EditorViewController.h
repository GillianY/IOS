//
//  EditorViewController.h
//  Ch04_NavigationController
//
//  Created by ucom Apple Instructor on 2016/11/29.
//  Copyright © 2016年 ucom Apple Instructor. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditorViewController : UIViewController
@property (strong,nonatomic) NSString * target;
@property (nonatomic) int row;
@end
