//
//  EditorViewController.swift
//  Ch08
//
//  Created by ucom Apple Instructor on 2016/11/30.
//  Copyright © 2016年 ucom Apple Instructor. All rights reserved.
//

import UIKit

class EditorViewController: UIViewController {

    //HW
    @IBAction func photoChooseHandler(sender: AnyObject) {
    }
    @IBAction func saveHandler(sender: AnyObject) {
        //收集使用者輸入
        current.name = nameInput.text!
        current.address = addressInput.text!
        current.photo = UIImagePNGRepresentation(imageView.image!)
        //資料儲存
        if sid == 0{
            ContactDAO.insert(current)
        }else{
            ContactDAO.update(current)
        }
        //回上一頁
        self.navigationController?.popViewControllerAnimated(true)
    }
    //UI
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var addressInput: UITextField!
    @IBOutlet var nameInput: UITextField!
    //Data
    var sid = 0
    var current = Contact()
    override func viewDidLoad() {
        super.viewDidLoad()
        if sid == 0{
            self.title = "新增"
        }else{
            self.title = "編輯"
            current = ContactDAO.getContactBySid(sid)
            nameInput.text = current.name
            addressInput.text = current.address
            if current.photo != nil{
                imageView.image = UIImage(data: current.photo!)
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
