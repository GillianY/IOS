//
//  Contact.swift
//  Ch08
//
//  Created by ucom Apple Instructor on 2016/11/30.
//  Copyright © 2016年 ucom Apple Instructor. All rights reserved.
//

import UIKit

class Contact: NSObject {
    var sid : Int = 0
    var name : String = ""
    var address : String = ""
    var photo : NSData?
}
