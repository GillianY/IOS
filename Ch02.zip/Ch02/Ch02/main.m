//
//  main.m
//  Ch02
//
//  Created by ucom Apple Instructor on 2016/11/25.
//  Copyright © 2016年 ucom Apple Instructor. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
