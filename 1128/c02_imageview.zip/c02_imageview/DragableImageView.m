//
//  DragableImageView.m
//  c02_imageview
//
//  Created by Gillian on 2016/11/28.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

#import "DragableImageView.h"

@implementation DragableImageView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
CGPoint startLocation;

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    startLocation = [[touches anyObject] locationInView:self];
    self.alpha=0.5;
    [self.superview bringSubviewToFront:self];
}

-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    CGPoint touchLocation = [[touches anyObject] locationInView:self];
    CGFloat dx = touchLocation.x - startLocation.x;
    CGFloat dy = touchLocation.y - startLocation.y;
    self.center = CGPointMake(self.center.x + dx, self.center.y + dy);

}
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    self.alpha=1;
}


@end
