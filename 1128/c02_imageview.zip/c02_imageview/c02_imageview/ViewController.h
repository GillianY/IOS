//
//  ViewController.h
//  c02_imageview
//
//  Created by Gillian on 2016/11/28.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

#import <UIKit/UIKit.h>

#define NUMS = 50

@interface ViewController : UIViewController


@end

