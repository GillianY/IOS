//
//  AppDelegate.m
//  c02_imageview
//
//  Created by Gillian on 2016/11/28.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

{
    NSUserDefaults * userDefults;
}
@end

@implementation AppDelegate


//error serials;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    NSLog(@"0 didFinishLaunchingWithOptions");
    
   //
//    if([userDefults objectForKey:@"Launched"] == nil){
//        NSLog(@"first run");
//        [userDefults setBool:YES forKey:@"Launched"];
//        [userDefults synchronize];
//    }else{
//        NSLog(@"Launched");
//    }
    
    
    
    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"INIT" message:nil delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [alert show];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     NSLog(@"2 applicationWillResignActive");
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    NSLog(@"3 applicationDidEnterBackground");

}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    NSLog(@"4 applicationWillEnterForeground");

}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    NSLog(@"1 applicationDidBecomeActive");
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"YYYY-MM-dd";
    //[formatter setDateFormat:@"YYYY-MM-dd"];
    NSString *today = [formatter stringFromDate:[NSDate date]];
    userDefults =[NSUserDefaults standardUserDefaults];
   
    NSString  *launcheday =[userDefults objectForKey:@"LAUNCHDATE"];
    BOOL isUPdate = YES;
    if(launcheday == nil || ![launcheday isEqualToString:today]){
        NSLog(@"first Launched Today");

    }else{
        isUPdate= NO;
        NSLog(@"Launched");
    }
    
    if(isUPdate){
        [userDefults setValue:today forKey:@"LAUNCHDATE"];
        [userDefults synchronize];
    }

}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    NSLog(@"5 applicationWillTerminate");

}

@end
