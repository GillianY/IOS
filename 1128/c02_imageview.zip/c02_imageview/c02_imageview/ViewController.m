//
//  ViewController.m
//  c02_imageview
//
//  Created by Gillian on 2016/11/28.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    CGRect winRect = self.view.frame;
    
   // for(int i =0; i< NUMS ; i++){
    for(int i =0; i< 50 ; i++){
        UIImageView *img = [[UIImageView alloc]initWithImage:[UIImage  imageNamed:@"Pumpkin01_64"]] ;
        img.center = CGPointMake(arc4random()%(int)winRect.size.width, arc4random()%(int)winRect.size.height);
        [self.view addSubview:img];
        
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)didReceiveMemoryWarning:(BOOL)animated{
    NSLog(@"");
}
-(void)viewWillAppear:(BOOL)animated{
    NSLog(@" viewWillAppear - 1");

}
-(void)viewDidAppear:(BOOL)animated{NSLog(@"viewDidAppear -2");

}
-(void)viewWillDisappear:(BOOL)animated{
    NSLog(@"");

}
-(void)viewDidDisappear:(BOOL)animated:(BOOL)animated{
    NSLog(@"");

}

@end
