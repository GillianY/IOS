//
//  DragableImageView.h
//  c02_imageview
//
//  Created by Gillian on 2016/11/28.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DragableImageView : UIView

@end
