//
//  EditorViewController.h
//  Ch04_NaviagationController
//
//  Created by ucom Apple 13 on 2016/11/29.
//  Copyright © 2016年 ucom Apple Instructor. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditorViewController : UIViewController

@property (strong,nonatomic) NSString *targetPath;
@property (nonatomic) int row;


@end
