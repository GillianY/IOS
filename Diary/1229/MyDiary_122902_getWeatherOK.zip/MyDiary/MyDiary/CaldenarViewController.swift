//
//  CaldenarViewController.swift
//  MyDiary
//
//  Created by ucom Apple 13 on 2016/12/24.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

import UIKit

class CaldenarViewController: UIViewController {
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var weekLabel: UILabel!
    @IBOutlet weak var tempture: UILabel!
    @IBOutlet weak var weatherCode: UILabel!
    
    @IBOutlet weak var weatherImageView: UIImageView!
    
    
    var weatherCondition: getWeatherInfo?;
    var weather:[String:String]? ;
    var getDataTime :String?;
    var today = NSDate();
    
    override func viewDidLoad(){
       // weatherCondition = getWeatherInfo();
        super.viewDidLoad();
        getTodayData();
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate ;
        weatherCondition = appDelegate.todayweather
    }
    
    
    
    func getTodayData(){
        yearLabel.text = DiaryItem.dategetYear(today);
        monthLabel.text = DiaryItem.dategetMonth(today);
        dayLabel.text = DiaryItem.dategetDay(today);
        weekLabel.text = DiaryItem.dategetWeek(today);
       //  NSThread.sleepForTimeInterval(3) ;
       
    }
    
    override func viewWillAppear(animated: Bool) {
        
        weather = weatherCondition!.JsondataArray;
       //  print("2getTodayData-----\((weatherCondition!.JsondataArray)["text"]) \(weather!["temp"]) \(weather!["code"])");
        weatherCode.text = weather!["text"];
        getDataTime = weather!["date"];
        tempture.text = weather!["temp"];
        weatherImageView.image = (weatherCondition?.getWeatherImage())!;
        
        // print("caledar\(weatherCode.text) ,\(tempture.text)");
    }
    
    
    
}
