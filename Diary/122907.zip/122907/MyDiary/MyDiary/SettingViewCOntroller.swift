//
//  SettingViewCOntroller.swift
//  MyDiary
//
//  Created by ucom Apple 13 on 2016/12/29.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

import UIKit

class SettingViewCOntroller: UIViewController {

    @IBAction func closeSetting(sender: UIButton) {
        
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    
}
