//
//  DataKeeper.h
//  MyDiary
//
//  Created by ucom Apple 13 on 2016/12/22.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataKeeper : NSObject

   // static DataKeeper *sharedGizmoManager ; //= nil;
@property (strong ,nonatomic) NSData *photoData ;

@end
