//
//  mainDiaryMonthTVHeaderCell.swift
//  MyDiary
//
//  Created by Gillian on 2016/12/18.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

import UIKit

class mainDiaryMonthTVHeaderCell: UITableViewCell {

    @IBOutlet weak var monthLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
