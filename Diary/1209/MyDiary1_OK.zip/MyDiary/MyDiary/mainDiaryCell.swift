//
//  mainDiaryCell.swift
//  MyDiary
//
//  Created by ucom Apple 13 on 2016/12/8.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

import UIKit

class mainDiaryCell: UITableViewCell {
    @IBOutlet weak var diaryWeek: UILabel!
    
    
    @IBOutlet weak var dauryWeek: UILabel!
    @IBOutlet weak var weather: UIImageView!
    @IBOutlet weak var Day: UILabel!
    @IBOutlet weak var diaryTitle: UILabel!
    
    

}
