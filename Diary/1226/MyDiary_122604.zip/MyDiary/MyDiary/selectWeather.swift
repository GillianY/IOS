//
//  selectWeather.swift
//  MyDiary
//
//  Created by ucom Apple 13 on 2016/12/26.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

import UIKit

class selectWeather: UIViewController {
    
    
    
    
    func getJsonFromNetwork(){
        let urlString = "https://query.yahooapis.com/v1/public/yql?q=select%20item.condition%20from%20weather.forecast%20where%20woeid%20%3D%202306179%20and%20u%3D%22c%22&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";
        
        let request = NSMutableURLRequest(URL: NSURL(string: urlString)!)
        
        let session = NSURLSession.sharedSession()
        request.HTTPMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        // or if you think the conversion might actually fail (which is unlikely if you built `parameters` yourself)
        //
         do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(params, options: [])
         } catch {
            print(error)
         }
        
//        let dataString = NSString(data: data!, encoding: NSUTF8StringEncoding)!
//        println(dataString)
        
        let task = session.dataTaskWithRequest(request) { data, response, error in
            guard let data = data where error == nil else {
                print("error: \(error)")
                return
            }
            
            // this, on the other hand, can quite easily fail if there's a server error, so you definitely
            // want to wrap this in `do`-`try`-`catch`:
            do {
                if let json = try NSJSONSerialization.JSONObjectWithData(data, options: []) as? NSDictionary {
                    let success = json["success"] as? Int                                  // Okay, the `json` is here, let's get the value for 'success' out of it
                    print("Success: \(success)")
                } else {
                    let jsonStr = String(data: data, encoding: NSUTF8StringEncoding)    // No error thrown, but not NSDictionary
                    print("Error could not parse JSON: \(jsonStr)")
                }
            } catch let parseError {
                print(parseError)                                                          // Log the error thrown by `JSONObjectWithData`
                let jsonStr = String(data: data, encoding: NSUTF8StringEncoding)
                print("Error could not parse JSON: '\(jsonStr)'")
            }
        }
        
        task.resume()


    
    }
    
    
    
   static var weather_con = [
    "0":"龍捲風",
    "1":"熱帶風暴",
    "2":"颶風",
    "3":"強雷陣雨",
    "4":"雷陣雨",
    "5":"混合雨雪",
    "6":"混合雨雪",
    "7":"混合雨雪",
    "8":"冰凍小雨",
    "9":"細雨",
    "10":"凍雨",
    "11":"陣雨",
    "12":"陣雨",
    "13":"飄雪",
    "14":"陣雪",
    "15":"吹雪",
    "16":"下雪",
    "17":"冰雹",
    "18":"雨雪",
    "19":"多塵",
    "20":"多霧",
    "21":"陰霾",
    "22":"多煙",
    "23":"狂風大作",
    "24":"有風",
    "25":"冷",
    "26":"多雲",
    "27":"晴間多雲（夜）",
    "28":"晴間多雲（日）",
    "29":"晴間多雲（夜）",
    "30":"晴間多雲（日）",
    "31":"清晰的（夜）",
    "32":"晴朗",
    "33":"晴朗（夜）",
    "34":"晴朗（日）",
    "35":"雨和冰雹",
    "36":"炎熱",
    "37":"雷陣雨",
    "38":"零星雷陣雨",
    "39":"零星雷陣雨",
    "40":"零星雷陣雨",
    "41":"大雪",
    "42":"零星陣雪",
    "43":"大雪",
    "44":"多雲",
    "45":"雷陣雨",
    "46":"陣雪",
    "47":"雷陣雨",
    "3200":"資料錯誤"
    ];


}
