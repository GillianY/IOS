//
//  ToDoListItem.swift
//  MyDiary
//
//  Created by Gillian on 2016/12/25.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

import UIKit

class ToDoListItem: NSObject {
    var miid :Int = 0;
    var mid :Int = 0;
    var title :String = "";

}
