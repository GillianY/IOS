//
//  PhotoPicker.h
//  MyDiary
//
//  Created by ucom Apple 13 on 2016/12/21.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PhotoPicker : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (strong ,nonatomic) NSData *photoData ;

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property ( nonatomic)int diaryDid ;
- (IBAction)shotPhoto:(UIBarButtonItem *)sender;

- (IBAction)shotHandler:(UIBarButtonItem *)sender;
- (IBAction)pickPhoto:(UIBarButtonItem *)sender;


@end
