//
//  ViewController.swift
//  GinaTest
//
//  Created by ucom Apple 13 on 2016/12/13.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var uptoolbar: UIToolbar!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let navigationBar = navigationController!.navigationBar
        navigationBar.setBackgroundImage(UIImage(named: "BarBackground"),
                                         forBarMetrics: .Default)
        navigationBar.shadowImage = UIImage()
      
        
        uptoolbar.layer.borderWidth = 1;
        uptoolbar.layer.borderColor =  UIColor.clearColor().CGColor;

        
    }
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

