//
//  mainDiaryCell.swift
//  MyDiary
//
//  Created by ucom Apple 13 on 2016/12/8.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

import UIKit

class mainDiaryCell: UITableViewCell {
//    @IBOutlet weak var timelabel: UILabel!
//    @IBOutlet weak var weeklabel: UILabel!
//    @IBOutlet weak var diarytitlelabel: UILabel!
//    @IBOutlet weak var daylabel: UILabel!
    @IBOutlet weak var timelabel: UILabel!
    
    @IBOutlet weak var weeklabel: UILabel!

    @IBOutlet weak var diarytitlelabel: UILabel!
    @IBOutlet weak var daylabel: UILabel!
}
