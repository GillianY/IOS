//
//  imgPickerViewController.h
//  CH07_ImagePicker
//
//  Created by ucom Apple 13 on 2016/11/30.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface imgPickerViewController : UIViewController

@end
