//
//  Users.h
//  ch08
//
//  Created by ucom Apple 13 on 2016/11/30.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Users : NSObject
@property(strong,nonatomic) NSData * photo;
@property(strong,nonatomic) NSString * address;
@property(strong,nonatomic) NSString * name;
@property(nonatomic) int *sid; //??

@end
