//
//  contact.swift
//  ch08
//
//  Created by ucom Apple 13 on 2016/11/30.
//  Copyright © 2016年 Gillian_studio. All rights reserved.
//

import UIKit

class Contact: NSObject {
    
    var sid :Int = 0
    var name : NSString = ""
    var address: NSString = ""
    var photo : NSData?
    
    

}
